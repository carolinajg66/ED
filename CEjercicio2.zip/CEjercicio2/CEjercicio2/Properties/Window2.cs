using System;

namespace CEjercicio2
{
	public partial class Window2 : Gtk.Window
	{
		public Window2 () : 
				base(Gtk.WindowType.Toplevel)
		{
			this.Build ();
		}
	}
}

